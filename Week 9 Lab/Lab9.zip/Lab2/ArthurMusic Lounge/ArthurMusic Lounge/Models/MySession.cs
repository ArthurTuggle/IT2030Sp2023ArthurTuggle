﻿using Microsoft.AspNetCore.Mvc;

namespace ArthurMusic_Lounge.Models
{
    // The MySession class represents the session state information
    public class MySession
    {
        public string FirstName { get; set; } 
        public string LastName { get; set; } 
        public string Course { get; set; } 
        public int FavNum { get; set; } 
    }
}

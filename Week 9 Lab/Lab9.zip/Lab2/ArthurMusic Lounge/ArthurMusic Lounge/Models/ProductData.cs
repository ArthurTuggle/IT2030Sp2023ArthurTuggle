﻿using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace ArthurMusic_Lounge.Models
{
    public class ProductData
    {

        public static List<ProductModel> GetProducts()
        {

            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel {
                    ProductId = 1,
                    ProductName = "Flute",
                    ProductDescription = "Woodwind Instrument",
                    ProductImage = "Flute.jpg",
                    ProductPrice = 1500
                },

                new ProductModel {
                ProductId = 2,
                ProductName = "Clarinet",
                ProductDescription = "Woodwind Instrument",
                ProductImage = "Clarinet.jpg",
                ProductPrice = 1000
                },

                new ProductModel
                {
                    ProductId = 3,
                    ProductName = "Drums",
                    ProductDescription = "Percussion Instrument",
                    ProductImage = "Drums.jpg",
                    ProductPrice = 800
                },

                new ProductModel
                {
                    ProductId = 4,
                    ProductName = "Saxophone",
                    ProductDescription = "Woodwind Instrument",
                    ProductImage = "Saxophone.jpg",
                    ProductPrice = 1750
                },

                new ProductModel
                {
                    ProductId = 5,
                    ProductName = "Trumpet",
                    ProductDescription = "Brass Instrument",
                    ProductImage = "Trumpet.jpg",
                    ProductPrice = 1200
                },

                new ProductModel
                {
                    ProductId = 6,
                    ProductName = "Tuba",
                    ProductDescription = "Brass Instrument",
                    ProductImage = "Tuba.jpg",
                    ProductPrice = 2000
                },

           };

            return products;

        }
        
        public static ProductModel GetProduct(int id)
        {

            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products)
            {
                if (product.ProductId == id)
                {
                    return product;
                }

            }
            return new ProductModel();

        }
    }

}





 











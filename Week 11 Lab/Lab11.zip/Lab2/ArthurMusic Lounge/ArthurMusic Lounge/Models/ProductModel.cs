﻿using System.ComponentModel.DataAnnotations;

namespace ArthurMusic_Lounge.Models
{
    public class ProductModel
    {
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Product name is required.")]
        public string ProductName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Product description is required.")]
        public string ProductDescription { get; set; } = string.Empty;

        [Required(ErrorMessage = "Product image is required.")]
        public string ProductImage { get; set; } = string.Empty;

        [DataType(DataType.Currency)]
        public decimal ProductPrice { get; set; }
    }
}
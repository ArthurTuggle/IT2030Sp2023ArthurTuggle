﻿using ArthurMusic_Lounge.Models;
using Microsoft.AspNetCore.Mvc;

namespace ArthurMusic_Lounge.Controllers
{
    public class ProductController : Controller
    {
  
     public IActionResult ListProducts()
     {
        List<ProductModel> products = ProductData.GetProducts();
        return View(products);
     }

        public IActionResult Detail(int id)
        {
            ProductModel product = ProductData.GetProduct(id);
            return View(product);
        }


    }
}

﻿using ArthurMusic_Lounge.Models;
using Microsoft.AspNetCore.Mvc;

namespace ArthurMusic_Lounge.Controllers
{
    public class ContactController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(ContactModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // do something with the submitted form data, e.g. send an email

            return RedirectToAction("Index");
        }
    }
}

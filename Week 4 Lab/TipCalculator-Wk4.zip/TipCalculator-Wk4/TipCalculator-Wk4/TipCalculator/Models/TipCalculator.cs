using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;

namespace TipCalculator.Models
{
    public class Calculator
    {
        [Required(ErrorMessage = "Please enter a value for cost of meal.")]
        [Range(0.01, 10000000.0, ErrorMessage = "Cost of meal must be greater than zero.")]
        public double? MealCost { get; set; }

        public double CalculateTip(double percent)
        {
            if (MealCost.HasValue) 
            {
                // It seems that you are dividing the cost of the meal by the percent instead of multiplying it.To correct this, change the line to:
                var tip = MealCost.Value * percent;
                return tip;
                // missing semicolon
            }
            else
            {
                return 0;
            }
        }
    }
}